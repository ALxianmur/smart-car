/*
 * math_ex.c
 *
 *  Created on: 2022-10-09
 *      Author: sundm
 */
